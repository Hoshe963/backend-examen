export class CreateProductDto {

    name: string;
    description: string;
    price: number;
    id_category: number;

}